module Reline
  VERSION = '0.1.2'
end
