module RSS
  # The current version of RSS
  VERSION = "0.2.8"
end
